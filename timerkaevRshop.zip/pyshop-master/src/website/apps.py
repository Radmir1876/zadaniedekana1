from django.apps import AppConfig


class WebsiteConfig(AppConfig):
    """ Класс Website AppConfig """

    name = 'website'
