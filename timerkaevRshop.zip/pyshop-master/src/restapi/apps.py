from django.apps import AppConfig


class RestapiConfig(AppConfig):
    """ Класс Restapi AppConfig """

    name = 'restapi'
