""" Модуль приложений менеджера """

from django.apps import AppConfig


class ManagerConfig(AppConfig):
    """ Класс Manager AppConfig """

    name = 'manager'
