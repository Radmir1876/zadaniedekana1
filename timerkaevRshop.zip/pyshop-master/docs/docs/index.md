# PyShop

PyShop is a e-commerce website and REST API made in Python language, using Django and Django REST Framework.


## More information

* [Installing and Running](installation.md)
* [API Documentation](api.md)
